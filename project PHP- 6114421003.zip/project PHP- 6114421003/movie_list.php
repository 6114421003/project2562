<?php 
include_once 'assets/layouts/header.php'; 

include 'assets/scripts/connect.php';

$sql_query = 'SELECT * FROM movie';
$details = $conn->query($sql_query);
?>
<div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ข้อมูลภาพยนต์</h2>
                <br>
                <table class="table table-borderless">
                    <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>รหัส</th>
                                    <th colspan="1">ชื่อภาพยนต์(ไทย)</th>
                                    <th colspan="1">ชื่อภาพยนต์(อังกฤษ)</th>
                                    <th colspan="1">วันเปิดตัว</th>
                                    <th colspan="1">ผู้กำกับ</th>
                                    <th colspan="1">ระยะเวลา</th>
                                    <th colspan="1">ค่าตั่ว</th>
                                    <th colspan="1">สถานะภาพยนต์</th>
                                    <th colspan="1"></th>
                                </tr>
                            </thead>
                            <tbody>
                    <?php
                       
                        $sql =  'select mov_id,mov_tname,mov_ename,mov_date,mov_per,mov_time,mov_price,sta_name
                        from movie join status_movie on mov_sta_id=sta_id
                        order by mov_id
                        ';
                        $result = mysqli_query($conn,$sql);
                        while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                            echo '<tr>';
                            echo '<td>' . $row['mov_id'] . '</td>';
                            echo '<td>' . $row['mov_tname'].'</td>';
                            echo '<td>' . $row['mov_ename'].'</td>';
                            echo '<td>' . $row['mov_date'].'</td>';
                            echo '<td>' . $row['mov_per'].'</td>';
                            echo '<td>' . $row['mov_time'].'</td>';
                            echo '<td>' . $row['mov_price'].'</td>';
                            echo '<td>' . $row['sta_name'].'</td>';
                            echo '<td>';
                            ?>
                                <a href="movie_edit.php?mov_id=<?php echo $row['mov_id'];?>" class="btn btn-warning">แก้ไข</a>
                                <a href="JavaScript:if(confirm('ยืนยันการลบ')==true)
                                   {window.location='movie_delete.php?mov_id=<?php echo $row["mov_id"];?>'}" class="btn btn-danger">ลบ</a>
                            <?php
                                    echo '</td>';                            
                            echo '</tr>';
                        }
                        mysqli_free_result($result);
                        echo '</table>';
                        mysqli_close($conn);
                    ?>
                            </tbody>
                        </table>    
                    </table>
                   <a href="movie_add.php" class="btn btn-outline-success"  style="text-align:right;"  >  เพิ่มข้อมูลภาพยนต์</a>
                </div>    
            </div>
           


    </body>
</html>
<?php include_once 'assets/layouts/footer.php' ?>