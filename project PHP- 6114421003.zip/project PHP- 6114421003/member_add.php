<?php 
include_once 'assets/layouts/header.php'; 

include 'assets/scripts/connect.php';

$sql_query = 'SELECT * FROM movie';
$details = $conn->query($sql_query);
?>
 <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">เพิ่มข้อมูลสมาชิก</h2>
                <br>
                <?php
                        if(isset($_GET['submit'])){
                            $mem_cls_id = $_GET['mem_cls_id'];
                            $mem_fname = $_GET['mem_fname'];
                            $mem_number = $_GET['mem_number'];
                            $mem_birth= $_GET['mem_birth'];
                            $mem_date= $_GET['mem_date'];
                            $sql = "insert into member (mem_cls_id,mem_fname,mem_number,mem_birth,mem_date)";
                            $sql .= " values ('$mem_cls_id','$mem_fname','$mem_number','$mem_birth','$mem_date')";
                            echo $sql;

                            mysqli_query($conn,$sql);
                            mysqli_close($conn);
                            echo "<h2>เพิ่มข้อมูลสมาชิก เรียบร้อยแล้ว<br></h2>";
                            echo '<a class="btn btn-success" href="member_list.php">แสดงข้อมูลสมาชิกทั้งหมด</a>';
                        }else{
                    ?>
                    <form class="form-horizontal" role="form" name="games_add" action="<?php echo $_SERVER['PHP_SELF'];?>">
                        
                        <div class="form-group">
                            <label for="mem_fname" class="col-md-2 col-lg-2 control-label">ชื่อจริง</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mem_fname" id="mem_fname" class="form-control">
                            </div>    
                        </div> 
                         
                        <div class="form-group">
                            <label for="mem_lname" class="col-md-2 col-lg-2 control-label">นามสกุล</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mem_lname" id="mem_lname" class="form-control">
                            </div>    
                        </div>  
                        <div class="form-group">
                            <label for="mem_number" class="col-md-2 col-lg-2 control-label">เบอร์มือถือ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mem_number" id="mem_number" class="form-control">
                            </div>    
                        </div> 
                        
                       
                        <div class="form-group">
                            <label for="mem_birth" class="col-md-2 col-lg-2 control-label">วันเกิด</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mem_birth" id="mem_birth" class="form-control">
                                <h7>ปี/เดือน/วัน</h7>
                            </div>    
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="mem_date" class="col-md-2 col-lg-2 control-label">วันที่เป็นสมาชิก</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mem_date" id="mem_date" class="form-control">
                                <h7> ปี/เดือน/วัน </h7>
                            </div>    
                        </div>
                       
                       <hr>
                        <div class="form-group">
                            <label for="mem_cls_id" class="col-md-2 col-lg-2 control-label">ระดับสมาชิก</label>
                            <div class="col-md-10 col-lg-10">
                                <select name="mem_cls_id" id="mem_cls_id" class="form-control">
                                <?php
                                    include 'connectdb.php';
                                    $sql =  'SELECT * FROM class '
                                            . 'order by cls_id';
                                    $result = mysqli_query($conn,$sql);
                                    while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                                        echo '<option value=';
                                        echo '"' . $row['cls_id'] . '">';
                                        echo $row['cls_name'];
                                        echo '</option>';
                                    }
                                    mysqli_free_result($result);
                                    mysqli_close($conn);
                                ?>
                                </select>
                           </div>    
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-danger">
                            </div>    
                        </div> 
                    </form>
                    <?php
                        }
                    ?>
                </div>    
            </div>
           


    </body>
</html>
<?php include_once 'assets/layouts/footer.php' ?>