$(document).ready( function () {

    $('#search').keyup( function () {
        var keyword = $(this).val();
        $('#sub_search').removeClass('btn-dark');
        if(keyword.length > 0){
            $('#sub_search').prop('disabled', false);
            $('#sub_search').addClass('btn-info');
        }else{
            $('#sub_search').prop('disabled', true);
            $('#sub_search').addClass('btn-dark');
        }
    });
});


