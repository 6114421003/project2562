<?php
    define('HOSTNAME', 'localhost');
    define('DB_NAME', 'movie');
    define('USERNAME', 'root');
    define('PASSWORD', '');

    $conn = new mysqli(HOSTNAME, USERNAME, PASSWORD, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }