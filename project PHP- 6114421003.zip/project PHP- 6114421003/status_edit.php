<?php 
include_once 'assets/layouts/header.php'; 

include 'assets/scripts/connect.php';

$sql_query = 'SELECT * FROM movie';
$details = $conn->query($sql_query);
?>
 <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">แก้ไขสถานะภาพยนต์</h2>
                <br>
                <?php

                    if(isset($_GET['submit'])){
                        $sta_id     = $_GET['sta_id'];
                        $sta_name   = $_GET['sta_name'];
                       
                        $sql        = "update status_movie set sta_name='$sta_name' where sta_id='$sta_id'";
                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "แก้ไขสถานะ $sta_name เรียบร้อยแล้ว<br>";
                        echo '<a href="status_list.php">แสดงสถานะทั้งหมด</a>';
                    }else{
                        $fsta_id = $_REQUEST['sta_id'];
                        $sql =  "SELECT * FROM status_movie where sta_id='$fsta_id'";
    
                        $result = mysqli_query($conn,$sql);
                        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                        $fsta_name = $row['sta_name'];
                        
                        mysqli_free_result($result);
                        mysqli_close($conn);                        
                ?>
                    <form class="form-horizontal" role="form" name="tools_edit" action="<?php echo $_SERVER['PHP_SELF']?>">
                        <input type="hidden" name="sta_id" id="sta_id" value="<?php echo "$fsta_id";?>">
                        <div class="form-group">
                            <label for="sta_name" class="col-md-2 col-lg-2 control-label">สถานะ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="sta_name" id="sta_name" class="form-control" value="<?php echo "$fsta_name";?>">
                            </div>    
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-default">
                            </div>    
                        </div>
                    </form>
                <?php
                    }
                ?>
                </div>    
            </div>
           
 
    </body>
</html>
<?php include_once 'assets/layouts/footer.php' ?>