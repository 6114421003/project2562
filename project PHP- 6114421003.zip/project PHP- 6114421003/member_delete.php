<?php 
include_once 'assets/layouts/header.php'; 

include 'assets/scripts/connect.php';

$sql_query = 'SELECT * FROM movie';
$details = $conn->query($sql_query);
?>
   <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ลบข้อมูลสมาชิก</h2>
                <br>
                <?php
            $mem_id = $_GET['mem_id'];
            $sql = "delete from member where mem_id='$mem_id'";
            $result = mysqli_query($conn,$sql);
            if($result){
                echo 'ลบแล้ว';
            }else{
                echo 'ลบไม่ได้';
            }
            
            echo '<a href="member_list.php">แสดงข้อมูลสมาชิกทั้งหมด</a>';
        ?>
                </div>    
            </div>
           


    </body>
</html>
<?php include_once 'assets/layouts/footer.php' ?>