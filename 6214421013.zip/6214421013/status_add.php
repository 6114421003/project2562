<?php 
include_once 'assets/layouts/header.php'; 

include 'assets/scripts/connect.php';

$sql_query = 'SELECT * FROM movie';
$details = $conn->query($sql_query);
?>
 <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">เพิ่มสถานะภาพยนต์</h2>
                <br>
                <?php
                    if(isset($_GET['submit'])){
                        $sta_name = $_GET['sta_name'];
                        $sql = "insert into status_movie (sta_name) values ('$sta_name')";
                        echo $sql;

                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "เพิ่มสถานะ $sta_name เรียบร้อยแล้ว<br>";
                        echo '<a href=status_list.php>แสดงสถานะทั้งหมด</a>';
                    }else{
                ?>
                    <form class="form-horizontal" role="form" name="status_add" action="<?php echo $_SERVER['PHP_SELF']?>">
                        <div class="form-group">
                            <label for="sta_name" class="col-md-2 col-lg-2 control-label">สถานะ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="sta_name" id="sta_name" class="form-control">
                            </div>    
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-default">
                            </div>    
                        </div>
                    </form>
                <?php
                    }
                ?>
                </div>    
            </div>
           


    </body>
</html>
<?php include_once 'assets/layouts/footer.php' ?>